/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"
#include "PID.h"

using namespace vex;

// A global instance of competition
competition Competition;

// define your global instances of motors and other devices here

/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/
bool swtch = false;

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
 
  // All activities that occur before the competition starts
  // Example: clearing encoders, setting servo positions, ...
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/



//auton functions/methods set up//////////////////////////////////////////////////////





/////////Functions end here//////

//You guys dont need to touch the autonomous unless you're trying to code a new auton
void autonomous(void) {
 
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

//ANYTHING WRONG WITH USERCONTROL WILL BE IN THIS SECTION/////////////

int flywheelSpeed = 100; 
void usercontrol(void) {
  // User control code here, inside the loop
  while (1) {
    if(Controller1.Axis3.value() < 5 && Controller1.Axis3.value() > -5 && Controller1.Axis1.value() > -5 && Controller1.Axis1.value() < 5){
      //driving brake mode is here, change to brake if you feel like it's gliding too much
      LTop.stop(coast);
      RTop.stop(coast);
      RFront.stop(coast);
      LFront.stop(coast);
    }
    else{
      LTop.spin(fwd, (Controller1.Axis3.value() + Controller1.Axis4.value()), pct);
      LFront.spin(fwd, (Controller1.Axis3.value() + Controller1.Axis4.value()), pct);
      RFront.spin(fwd, (Controller1.Axis3.value() - Controller1.Axis4.value()), pct);
      RTop.spin(fwd, (Controller1.Axis3.value() - Controller1.Axis4.value()), pct);
    }

        // if(Controller1.ButtonUp.pressing()){
        //   flywheelSpeed += 10;
        // }
        // if(Controller1.ButtonDown.pressing()){
        //   flywheelSpeed -= 10;
        // }

        // if(flywheelSpeed >= 100){
        //   flywheelSpeed = 100;
        // } else if (flywheelSpeed <= 10){
        //   flywheelSpeed = 10;
        // }

        bool motorStateFW;
        if(Controller1.ButtonX.pressing()){
          motorStateFW = true;
        }
        if(Controller1.ButtonY.pressing()){
          motorStateFW = false;
        }

        if(motorStateFW == true){
          flywheelGroup.spin(fwd,flywheelSpeed,pct);
        } else{
          flywheelGroup.stop();
        }

//flywheel xy, roller left, intake right, piston remaining ab
        bool motorStateI;
        if(Controller1.ButtonR1.pressing()){
          motorStateI = true;
        }
        if(Controller1.ButtonR2.pressing()){
          motorStateI = false;
        }

        if(motorStateI == true){
          intake.spin(fwd,100,pct);
        } else{
          intake.stop();
        }

      //roller
        bool motorStateR;
        if(Controller1.ButtonL1.pressing()){
          motorStateR = true;
        }
        if(Controller1.ButtonL2.pressing()){
          motorStateR = false;
        }

        if(motorStateR == true){
          roller.spin(fwd,100,pct);
        } else{
          roller.stop();
        }

        if(Controller1.ButtonA.pressing()){
          pneu.set(true);
        }else if(Controller1.ButtonB.pressing()){
          pneu.set(false);
        }
        
      

        //turns the intake on when x is pressed and has it run constantly until the button y is pressed
        /*
        bool motorState;
        if(Controller1.ButtonX.pressing()){
          motorState = true;
        }
        if(Controller1.ButtonY.pressing()){
          motorState = false;
        }

        if(motorState == true){
          
        } else{
          
        }
        */
        


      
    
    // This is the main execution loop for the user control program. Hi this is David
    // Each time through the loop your program should update motor + servo
    // values based on feedback from the joysticks.

    // ........................................................................
    // Insert user code here. This is where you use the joystick values to
    // update your motors, etc.
    // ........................................................................
    
    
    
    Controller1.Screen.setCursor(1, 1);
    Controller1.Screen.clearScreen();
    Controller1.Screen.print(flywheelSpeed);
    wait(20, msec); 
    


    //just print statements you don't need to care about this
      // Brain.Screen.newLine();
      // Controller1.Screen.print(REnc.position(deg));
            }
    
    wait(20, msec); // Sleep the task for a short amount of time to
                    // prevent wasted resources.
   }


//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}
